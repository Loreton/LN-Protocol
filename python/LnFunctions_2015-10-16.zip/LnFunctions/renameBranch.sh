#!/bin/sh
# https://github.com/sschuberth/dev-scripts/tree/master/git
remoteSite=$1
oldName=$2
newName=$3

if [ $# -ne 3 ]; then
    echo
    echo "Rationale : Rename a branch on the server without checking it out."
    echo "Usage     : $(basename $0) <remoteSite> <old name> <new name>"
    echo "Example   : $(basename $0) origin master release"
    echo
    exit 1
fi



# MODE1
#echo git push $remoteSite $remoteSite/$oldName:refs/heads/$newName :$oldName
#git push $remoteSite $remoteSite/$oldName:refs/heads/$newName :$oldName


# VERIFICATO - E' perfetto . Usare -M per forzare il rename
# http://git-scm.com/docs
echo
echo ------------ First checkout to the branch which you want to rename
echo git checkout $oldName
echo
echo ------------ rename the local branch
echo git branch -m $oldName $newName
echo
echo ------------ push it to remoteSite
echo git push $remoteSite $newName
echo
echo ------------ To remove old branch from remoteSite:
echo git push $remoteSite :$oldName
echo
echo
echo