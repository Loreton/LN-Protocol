#!/usr/bin/python -O
# -*- coding: latin-1 -*-
# -*- coding: iso-8859-1 -*-
# -O Optimize e non scrive il __debug__


# =========================================================================
# - Ritorna:
# =========================================================================
def removeItem(gv, LIST, value, strip=False):
    LN          = gv.LN
    logger      = gv.LN.logger
    calledBy    = gv.LN.sys.calledBy
    logger.debug('entered - [called by:%s]' % (calledBy(1)))

    if strip:
        lista = [item.strip() for item in LIST if item != value]
    else:
        lista = [item for item in LIST if item != value]


    return lista

################################################################################
# - M A I N
################################################################################
if __name__ == "__main__":
    a = [0, 1, 1, 0, 1, 2, 1, 3, 1, 4]
    b = ['']
    removeFromList(a, 0)