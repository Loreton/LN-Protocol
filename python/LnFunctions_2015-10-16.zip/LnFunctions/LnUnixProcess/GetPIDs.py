#!/usr/bin/python -O
# -*- coding: iso-8859-1 -*-
# -*- coding: latin-1 -*-
#                                               by Loreto Notarantonio 2013, February
# ######################################################################################

import sys, re

# #####################################################################
# # Return the PID list if processName is provided
# # if str2Search is provided, will search for it in the parameter value
# #####################################################################
def getPIDs(gv, processName, str2Search=None):
    logger      = gv.LN.logger.setLogger(gv, pkgName=__name__)
    calledBy    = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(1)))

    command = "ps"
    args = ['ax', '-o', 'pid', '-o', 'args']
    rCode, output, err = gv.LN.proc.runCommand(gv, command, argsList=args, PWAIT=True, exitOnError=True)

    PIDs = []
    for line in output.split("\n"):
        line = line.strip()                 # IMPORTANTE
        if line == '': continue
        (pid, process) = line.split(' ', 1)
        if process.find(processName) >= 0:
            if str2Search:
                if process.find(str2Search) >= 0:
                    PIDs.append(pid)
            else:
                PIDs.append(pid)

    logger.info('FOUND the following PIDs: {}'.format(PIDs))

    logger.info('exiting - [called by:%s]' % (calledBy(1)))
    return PIDs

# #####################################################################
# # Return the PID list if processName is provided
# # if str2Search is provided, will search (using Regular Expressions)
# # for it in the parameter value
# #####################################################################
def getPIDsRE(gv, processName, str2Search):
    logger      = gv.LN.logger.setLogger(gv, pkgName=__name__)
    calledBy    = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(2)))

    p = re.compile(str2Search)

    command = "ps"
    args = ['ax', '-o', 'pid', '-o', 'args']
    rCode, output, err = gv.LN.proc.runCommand(gv, command, argsList=args, PWAIT=True, exitOnError=True)

    PIDs = []
    for line in output.split("\n"):
        line = line.strip()                 # IMPORTANTE
        if line == '': continue
        (pid, process) = line.split(' ', 1)
        if process.find(processName) >= 0:
            m = p.match(process)
            if m is not None:
                PIDs.append(pid)

    logger.info('FOUND the following PIDs: {}'.format(PIDs))

    logger.info('exiting - [called by:%s]' % (calledBy(1)))
    return PIDs



