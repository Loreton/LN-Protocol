#!/usr/bin/python -O
# -*- coding: iso-8859-1 -*-
# -*- coding: latin-1 -*-
#                                               by Loreto Notarantonio 2013, February
# ######################################################################################


# ##################################
# # printRetVal
# ##################################
def setJBossUid(gv):
    logger   = gv.LN.logger.setLogger(gv, pkgName=__name__)
    calledBy = gv.LN.sys.calledBy
    logger.info('entry - [called by:%s]' % (calledBy(2)))

    TAB = ' '*5

    JBossName = gv.JBOSS.userName

    JBossUID = pwd.getpwnam(JBossName).pw_uid
    JBossGID = pwd.getpwnam(JBossName).pw_gid

    currUID = os.getuid()
    if currUID == 0:
        os.setegid(gID)     # mantenere l'ordine GID-UID
        os.seteuid(uID)     # mantenere l'ordine GID-UID
        # print (uID, currUID)
        # print(os.getuid())
    elif currUID == JBossUID:
        print ('nothing to do...')
