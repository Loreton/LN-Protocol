import types, os, inspect, sys


EXIT_KEYB   = -30
PAUSE_KEYB   = -31
EXIT_STACK  = -32

# =======================================================================
# - 13 Maggio 2010  : Aggiunto il parametro stackLevel
# - stackLevel viene impostato per indicare un livello diverso del chiamante
# - Ad esempio la Prj.exit() chimaera wuesta exit con stackLevel=2 in modo
# - da saltare se stessa.
# =======================================================================
def exit(gv, rcode, text, printStack=False, stackLevel=9, console=True):
    logger = gv.LN.logger.setLogger(gv, pkgName=__name__)
    calledBy    = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(stackLevel)))

    if text == None:
        textList = ['No error message passed']
    elif isinstance(text, list):
        textList = text
        pass
    else:
        textList = text.split('\n')

        # -------------------------------
        # - Display dell'Errore
        # -------------------------------
    if rcode == 0:
        TEXT_COLOR = gv.LN.cGREEN
        logWrite = logger.debug
    else:
        TEXT_COLOR = gv.LN.cERROR
        logWrite = logger.error


        # -------------------------------
        # - Display dello STACK
        # -------------------------------
    if printStack:
        print(gv.LN.cGREEN + "EXIT STACK:")
        for i in reversed(list(range(1, 10))):
            caller = calledBy(i)
            if not 'index out of range' in caller:
                print(gv.LN.cGREEN + "    %s" % (caller))

        print(TEXT_COLOR + "[RCODE: %d]" % (rcode))
        print(TEXT_COLOR + "[TEXT Message:]" )
        for line in textList:
            print(gv.LN.cWARNING + ' '*10 + "%s" % (line))

    logWrite("EXIT STACK:")
    for i in reversed(list(range(1, 10))):
        caller = calledBy(i)
        if not 'index out of range' in caller:
            logWrite("    %s" % (caller))

    logWrite("[RCODE: %d]" % (rcode))
    logWrite("[TEXT Message:]" )
    for line in textList:
        logWrite(' '*10 + "%s" % (line))
        if console:
            print (TEXT_COLOR + line)

    print (gv.LN.cRESET)
    logWrite(gv.LN.cRESET)

    # logger.info('exiting - [called by:%s]' % (calledBy(stackLevel)))
    sys.exit(rcode)


def callerPrint(gv, deepLevel=1, rcode=0, BlankLINES=5, Indent="=     "):
    # logger      = gv.LN.logger
    logger      = logging.getLogger(baseLoggerName)
    calledBy    = gv.LN.sys.calledBy
    logger.debug('entered - [called by:%s]' % (calledBy(1)))

    caller = inspect.stack()[deepLevel]
    programFile = caller[1]
    lineNumber  = caller[2]
    funcName    = caller[3]
    if caller[4]:
        lineCode = caller[4][0]
    else:
        lineCode = 'UNKNOWN source line code'

    lun = len(lineCode) + 25
    lun = len(lineCode) + 5

    riga = []
    riga.append("\n"*BlankLINES)
    riga.append("%s" % (Indent) + "-"*lun)
    riga.append("%s" % (Indent) + "         C A L L E R")
    riga.append("%s" % (Indent))

    fname = os.path.basename(programFile).split('.')[0]
    riga.append("%s %-10s: %s.%s:[%s]" % (Indent, "called by:",        fname, funcName, lineNumber))
    riga.append("%s %-10s: %s" % (Indent, "Line code",           lineCode.strip()))
    riga.append("%s" % (Indent) + "-"*lun)
    riga.append("")


    if rcode == 0:
        logWrite = logger.debug
    else:
        logWrite = logger.error

    for line in riga:
        logWrite(line)

    logger.debug('exiting - [called by:%s]' % (calledBy(1)))