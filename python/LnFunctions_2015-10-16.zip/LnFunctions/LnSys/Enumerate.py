#!/usr/bin/python -O
# -*- coding: iso-8859-15 -*-
# Enumerate


class enumerateClass1(object):
    def __init__(self, names):
        for number, name in enumerate(names.split()):
            setattr(self, name, number)



# http://stackoverflow.com/questions/36932/how-can-i-represent-an-enum-in-python
# Call: Numbers = enum(ONE=1, TWO=2, THREE='three')
def enumerateClass2(**enums):
    return type('Enum', (), enums)


def enumerateClass2A(*sequential, **named):
    enums = dict(zip(sequential, range(len(sequential))), **named)
    return type('Enum', (), enums)

def enumerateClass3(*sequential, **named):
    enums = dict(zip(sequential, range(len(sequential))), **named)
    reverse = dict((value, key) for key, value in enums.items())
    enums['reverse_mapping'] = reverse
    return type('Enum', (), enums)

'''
import types
def Enumerate(data):
    valueType    = type(data)
    retValue = None
    if valueType in [types.StringType, types.UnicodeType]:
        retValue =  enumerate(data.split())
    elif valueType in [types.ListType, types.TupleType]:
        retValue =  enumerate(data)

    return retValue

'''


