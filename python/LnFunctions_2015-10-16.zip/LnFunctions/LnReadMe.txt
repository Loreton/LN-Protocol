# git config --global http.proxy http://utenze\\xf602250:password@itaca-prod.utenze.bankit.it:8080
# git config --global --unset http.proxy


##############################################################################
Per fare DEBUG remoto:
SERVER: rpdb2 -d -r __main__.py (chiede anche la password di connessione)
GUI:    winpdb
        file->password
        file->attach [nome del server]
##############################################################################
# Rename Origin
# git remote rename origin esil904


# PYTHON3 - gitHub
git clone git@github.com:Loreton/JBossAdmin.git           JBossAdmin
# PYTHON2 - gitUtenze



# Salvare alcune modifiche senza fare commit
git stash

# This will destroy any local modifications.
# Don't do it if you have uncommitted work you want to keep.
git reset --hard 0d1d7fc32

# Alternatively, if there's work to keep:
git stash
git reset --hard 0d1d7fc32
git stash pop
# This saves the modifications, then reapplies that patch after resetting.
# You could get merge conflicts, if you've modified things which were
# changed since the commit you reset to



#                       https://drupal.org/node/1066342
# Tags
    git tag -a v0.0.1 -m 'JBossAdmin v0.0.1 2014-06-16'
    git push github --tags

# Once the tag is created, you need to push the tag up to the master repository.
# By itself, push doesn't send the tags up, you also need to tell it to include
# the tags in the push by appending the --tags flag:
    git push gitHub --tags                         # push all tags
    git push gitHub tag v0.0.1             # If you don't want to push all your tags, you can also be specific:

# To check and confirm remote tags command is
    git tag -l
# To show
    git show v0.0.1


# Delete TAG
    git tag -d v1.0.0
    git push origin :refs/tags/v1.0.0



# BRANCH

# Create a branch from tag
git checkout -b myBranch v1.0.1

# move to branch
git checkout myBranch

#Push the branch on github :
$ git push    origin myBranch
$ git push -u origin myBranch    # crea il branch anche su remoto


# Applica quanto salvato a questo branch
git stash apply

# per fare il push:
git push -u github userProfile


# http://gitref.org/branching/
git branch              # display branches
git checkout master     # move to master
git merge devel     # merge to master

