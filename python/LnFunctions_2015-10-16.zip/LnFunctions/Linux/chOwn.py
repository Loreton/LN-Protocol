#!/usr/bin/python -O
# -*- coding: iso-8859-1 -*-
# -*- coding: latin-1 -*-
#                                               by Loreto Notarantonio 2013, February
# ######################################################################################
import sys
import os
import pwd, grp



def chOwn(gv, fileName, user_group=None, UID=-1, GID=-1):
    logger = gv.LN.logger.setLogger(gv, pkgName=__name__)

    TAByel      = gv.LN.cYELLOW + ' '*8
    TABerr      = gv.LN.cERROR + ' '*8

    if user_group:
        if user_group == '-:-': return 0
        userName, groupName = user_group.split(':')
        stat = os.stat(fileName)
        UID  = pwd.getpwnam(userName).pw_uid
        GID  = grp.getgrnam(groupName).gr_gid

    msg = "Before1 {} - chown {} {} {}".format(os.geteuid(), fileName, UID, GID)
    # print (msg)
    realUID, eUID, savedUID = os.getresuid()         # SAVE dello user corrente
    # msg = "Before2 {} - chown {} {} {}".format(os.geteuid(), fileName, UID, GID)
    # print (msg)
    rCode = 1
    errMsg = ''
    try:
        '''
        savedUID = os.geteuid()         # SAVE dello user corrente
        os.seteuid(os.getuid())         # impostiamo il REAL_USER
        os.chown(fileName, UID, GID)    # mantenere l'ordine GID-UID
        os.seteuid(savedUID)            # ripristiniamo lo user
        '''

        os.seteuid(realUID)         # impostiamo il REAL_USER
        os.chown(fileName, UID, GID)    # mantenere l'ordine GID-UID
        print('OK')
        rCode = 0

    except PermissionError as why:
        errMsg = "chown: - Permission Error {}".format(str(why))
        print(TABerr + errMsg)

    except:
        errMsg = "Unexpected ERROR: {}".format(msg, str(sys.exc_info()[0]))
        print(TABerr + errMsg)

    # finally:
    #     print('ERR3', rCode)

    os.seteuid(savedUID)            # ripristiniamo lo user
    return rCode


def printError(logger, errMsg):

    # dictID = vars(errMsg)
    dictID = errMsg
    # logger.info('---- INPUT Parameters Start ---')
    for key, val in dictID.items():
        logger.info('{:<20} : {}'.format(key, val))
    # logger.info('---- INPUT Parameters End   ---')