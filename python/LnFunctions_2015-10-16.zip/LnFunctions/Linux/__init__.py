# outer __init__.py
# -*- coding: iso-8859-1 -*-

import platform

if platform.system() == 'Windows':
    pass
else:
    from .WhoAmI                  import getUserName, getUID

from .RunCommand                 import runCommand
from .GetPidWithCommandLineArgs      import getPidWithCommandLineArgs
from .GetPIDs    import getPIDs
from .GetPIDs    import getPIDsRE       # regExpressions
