# BRANCH
remoteSite=gitHub
branchName=LnDevel


echo # Create a new branch
echo git branch $branchName
echo
echo # move to branch
echo git checkout $branchName
echo
echo # Push the branch on gitHub (non ho capito il flag -u)
echo git push    $remoteSite $branchName
echo # git push -u origin myBranch    # crea il branch anche su remoto
echo


