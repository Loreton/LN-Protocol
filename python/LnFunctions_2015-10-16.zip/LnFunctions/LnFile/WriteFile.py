# ##############################################################################################
# - writeFile()
# -*- coding: iso-8859-1 -*-
# -                                        by: Loreto Notarantonio (2010-02-16)
# ##############################################################################################
import os
import types
import unicodedata
# =========================================================================
# = 2013-02-12
# = Write Data (String or LIST) to file
# =========================================================================
def writeFile(gv, outFname, data, append=False, lineSep='\n', exitOnError=False):
    logger      = gv.LN.logger.setLogger(gv, pkgName=__name__)
    calledBy    = gv.LN.sys.calledBy
    # pColor      = gv.LN.sys.colors()
    logger.info('entered - [called by:{}]'.format(calledBy(1)))

    bERROR, errMSG = False, ''

    logger.debug("Writing file {}".format(outFname) )
    try:
        if append:
            FILE = open(outFname, "a")
        else:
            FILE = open(outFname, "wb")

        # print('........................type', type(data), outFname)
        if isinstance(data, list):
            for line in data:
                logger.debug(line)
                line = "{}{}".format(line, lineSep)
                FILE.write(bytes(line, 'UTF-8'))       # con Python3 bisogna convertirlo in bytes

        elif isinstance(data, bytes):
            FILE.write(data)

        elif isinstance(data, str):         # con Python3 bisogna convertirlo in bytes
            FILE.write(bytes(data, 'UTF-8'))

        else:   # binary?
            FILE.write(data)
            # errMSG = "TYPE=[{}] NON contemplato... Provvedere ad inserirlo".format((type(val)) )
            # bERROR = True

        FILE.close()

    except (IOError, os.error) as why:
        errMSG = "ERROR writing file - {}".format(str(why))
        bERROR = True

    if bERROR:
        logger.error(errMSG)
        if exitOnError:
            gv.LN.sys.exit(gv, 1001, errMSG, console=True)

    logger.info('exiting - [called by:{}]'.format(calledBy(1)))

    return errMSG


# =========================================================================
# = 2013-02-12
# = Write Data (String or LIST of LIST) to file - Da problemi con caratteri speciali
# =========================================================================
def writeFile_ListOfList(gv, outFname, data, append=True, commentStr=False, lineSep='\n'):
    logger      = gv.LN.logger
    calledBy    = gv.LN.sys.calledBy
    logger.debug('entered - [called by:%s]' % (calledBy(1)))

    try:
        if append:
            FILE = open(outFname, "a")
        else:
            FILE = open(outFname, "wb")

        if isinstance(data, list):
            for line in data:

                if isinstance(line, list):
                    print('.........', line)
                    for item in line:
                        print('.........', item)
                        # xx = unicodedata.normalize('NFKD', str(item)).encode('ascii', 'ignore')
                        FILE.write(item + ';')
                    FILE.write(lineSep)

                else:
                    FILE.write(line + lineSep)

        elif isinstance(data, bytes):
            FILE.write(data)

        else:
            logger.error( "TYPE=[%s] NON contemplato... Provvedere ad inserirlo" % (type(val)) )

        FILE.close()

    except (IOError, os.error) as why:
        strError = "ERROR reading File [%s]:\n       %s" % (outFname, str(why))
        logger.error(strError)
        exit(8, strError, stackLevel=4 )

    logger.debug('exiting - [called by:%s]' % (calledBy(1)))

    return




