#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# Scope: Lettura e scrittura di un file di configurazione nel formato INI
# ######################################################################################

import configparser

import logging
fullPackageName = __name__.split('.')
baseLoggerName  = ('.'.join(fullPackageName[-2:]))


# ######################################################
# # https://docs.python.org/3/library/configparser.html
def readIniFile(gv, iniFileName):
# ######################################################
    logger      = logging.getLogger(baseLoggerName)
    calledBy    = gv.LN.sys.calledBy
    logger.debug('entered - [called by:%s]' % (calledBy(1)))


    config = configparser.ConfigParser(allow_no_value=True, delimiters=('=', ':'), comment_prefixes=('#',';'), inline_comment_prefixes=(';',), strict=True, empty_lines_in_values=True, default_section='DEFAULT', interpolation=configparser.ExtendedInterpolation())

        # mantiene il case nei nomi delle section e delle Keys (Assicurarsi che i riferimenti a vars interne siano case-sensitive)
    config.optionxform = str

    config.read(iniFileName)

    logger.debug('exiting - [called by:%s]' % (calledBy(1)))

    return config



# ######################################################
def writeIniFile(gv, configDict, fileName):
# ######################################################
    logger      = logging.getLogger(baseLoggerName)
    calledBy    = gv.LN.sys.calledBy
    logger.debug('entered - [called by:%s]' % (calledBy(1)))

    with open(fileName, 'w') as configfile:
        configDict.write(configfile)

    logger.debug('exiting - [called by:%s]' % (calledBy(1)))

