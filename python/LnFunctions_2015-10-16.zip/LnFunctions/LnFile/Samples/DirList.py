#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

import os, fnmatch
import types



# ============================================================
# - dirList()
# Return a list of file names found in directory 'dirName'
#    pattern: ["*.x", "*x*.y*", ...]
#   deepFileIndicator   - è un nome di file che, se trovato, vuol dire che abbiamo raggiunto il livello massimo
#   deepLevelNO         - Numero di livello (subtree) da analizzare
#
# Example usage: fileList = dirList('H:\TEMP', '*.txt', 'F')
#       Only files with 'txt' extensions will be added to the list.
# Example usage: fileList = dirList('H:\TEMP', '*.txt;*.tx*', 'FS')
#       Only files with 'txt' extensions will be added to the list. Search in all Subdirs.
# Example usage: fileList = dirList('H:\TEMP', '*txt*', 'D')
#       Only Directories with 'txt' extensions will be added to the list.
#
# ============================================================
def dirList_Prev(gv, dirName, patternLIST=['*'], what='FDS', getFullPath=True, deepFileIndicator='1234ABCD.ZXC', deepLevelNO=99, static_MaxRCODE=[0]):
    logger      = gv.LN.logger.setLogger(gv, pkgName=__name__)
    calledBy    = gv.LN.sys.calledBy
    logger.info('entered - [called by:{0}]'.format(calledBy(1)))
    fDEBUG      = True # essendo ricorsivo è meglio controllare il logger manualmente altrimenti scrive moltissimo
    if fDEBUG:
        print ('deepLevelNO     :', deepLevelNO)
        print ('    dirName     :', dirName)
        print ('    patternLIST :', patternLIST)

    fileList    = []
    MaxRCODE    = 0

    FILES       = True if 'F' in what else False
    SUBDIRS     = True if 'S' in what else False
    DIRS        = True if 'D' in what else False


    if isinstance(patternLIST, str):patternLIST = [patternLIST]
    logger.debug("entering into dir: {0} searching for {1}".format(dirName, patternLIST) )


        # limit the Subdirs at current level (The next iteration do not enter into SubDirs)    - da aggiustare
    if os.path.isfile(os.path.join(dirName, deepFileIndicator) ):
        logger.info("deepFileIndicator [{0}] reached.".format(deepFileIndicator) )
        what = what.replace('S', '')    # Eliminiamo il il SUBDIRs

    if deepLevelNO <= 0:
        logger.info("exiting for deepLevelNO [{0}] reached.".format(deepLevelNO) )
        return MaxRCODE, fileList

    deepLevelNO -= 1

    # -----------------------------------------------
    # - file      = name of file without FullPath
    # - fullPathName   = name of file with    FullPath
    # -----------------------------------------------
    fSpec=''

    try:
        for fname in os.listdir(dirName):
            for fSpec in patternLIST:                           # Splitting the pattern
                logger.debug("working with pattern: {0}".format(fSpec) )
                fSpec = fSpec.strip()

                if fnmatch.fnmatch(fname, fSpec):    # cerca il MATCH nel nome del file
                    fullPathName = os.path.join(dirName, fname)
                    logger.debug("matched : {0}".format(os.path.join(fname, fSpec) ))

                    if FILES  and os.path.isfile(fullPathName):
                        if getFullPath: fileList.append( fullPathName)
                        else:           fileList.append( fname)
                    elif DIRS and os.path.isdir(fullPathName):
                        if getFullPath: fileList.append( fullPathName)
                        else:           fileList.append( fname)

                if SUBDIRS and os.path.isdir(fullPathName):
                    logger.debug("going into dir: %s" % (os.path.join(fullPathName, fSpec) ))
                    (rCode, newList) = dirList(gv, fullPathName, patternLIST=fSpec, what=what, getFullPath=getFullPath, deepFileIndicator=deepFileIndicator, deepLevelNO=deepLevelNO)
                    logger.debug("list found: %s" % (newList) )
                    MaxRCODE = max(MaxRCODE, rCode)
                    fileList.extend(newList)
                    logger.debug("exiting  from dir: %s" % (dirName) )

    except Exception as why:
        if dirName.find('System Volume Information') >= 0:
            pass
        else:
            logger.error("Listing directory:\n [{0}]\n\n {1}".format(os.path.join(dirName, fSpec), str(why)))
            MaxRCODE = max(MaxRCODE, 10)


    logger.debug("exiting  from dir: %s" % (dirName) )
    return MaxRCODE, fileList



import os
import stat, shutil
import platform;    OpSys = platform.system()


def dirList(gv, topDir, patternLIST=['*'], what='FDS', getFullPath=True, deepFileIndicator='1234ABCD.ZXC', deepLevelNO=99, static_MaxRCODE=[0], exitOnError=False):
    logger      = gv.LN.logger.setLogger(gv, pkgName=__name__)
    calledBy    = gv.LN.sys.calledBy
    logger.info('entered - [called by:{0}]'.format(calledBy(1)))
    fDEBUG      = True # essendo ricorsivo è meglio controllare il logger manualmente altrimenti scrive moltissimo
    if fDEBUG:
        print ('\n'*3)
        print ('deepLevelNO     :', deepLevelNO)
        print ('    topDir      :', topDir)
        print ('    patternLIST :', patternLIST)

    fileList    = []
    rCode       = 0

    FILES       = True if 'F' in what else False
    SUBDIRS     = True if 'S' in what else False
    DIRS        = True if 'D' in what else False

    try:
        for root, dirs, files in os.walk(topDir, topdown=False):
            print ('\n'*3)
            print ('root :', root)
            print ('dirs :', dirs)
            print ('files:', files)
            continue
            for fname in files:
                logger.debug("file: {0}".format(fname) )
                for fSpec in patternLIST:                           # Splitting the pattern
                    fSpec = fSpec.strip()

                    if fnmatch.fnmatch(fname, fSpec):    # cerca il MATCH nel nome del file
                        logger.debug("  {0} - matched".format(fSpec) )
                        fullPathName = os.path.join(root, fname)
                        print ( "working File: %s" % (fullPathName))
                        if FILES  and os.path.isfile(fullPathName):
                            if getFullPath: fileList.append( fullPathName)
                            else:           fileList.append( fname)
                    else:
                        logger.debug("  {0} - NOT matched".format(fSpec) )


            for dirName in dirs:
                print( "working  dir: %s" % (dirName))
                for fSpec in patternLIST:                           # Splitting the pattern
                    fSpec = fSpec.strip()

                    if fnmatch.fnmatch(dirName, Spec):    # cerca il MATCH nel nome del file
                        logger.debug("  {0} - matched".format(fSpec) )
                        fullPathName = os.path.join(root, dirName)
                        if DIRS and os.path.isdir(fullPathName):
                            if getFullPath: fileList.append( fullPathName)
                            else:           fileList.append( dirName)

    except Exception as why:
        msg = "ERRORE durante la lettura della directory: {}\n{}".format(topDir, str(why))
        logger.error(msg)
        if exitOnError:
            sys.exit()
        else:
            rCode = 1


    logger.info('exiting - [called by:{0}]'.format(calledBy(1)))
    return rCode, fileList