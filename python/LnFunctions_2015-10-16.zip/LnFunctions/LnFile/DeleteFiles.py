#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

# ##############################################################################################
# - delTree()
# - Per cancellare anche i file read-only
# -                                        by: Loreto Notarantonio (2014-01-05)
# ##############################################################################################
import os
import fnmatch, stat

def delTreeFiles(gv, topDir, fileSpec):
    logger  = gv.LN.logger.setLogger(gv, pkgName=__name__)

    if (topDir == '/' or topDir == "\\" or topDir == ''):
        return

    for root, dirs, files in os.walk(topDir, topdown=False):
        for name in files:
            filename = os.path.join(root, name)
            if fnmatch.fnmatch(name, fileSpec):    # cerca il MATCH nel nome del file
                logger.debug( "removing File: %s" % (filename))
                # print( "removing File: %s" % (filename))
                os.chmod(filename, stat.S_IWUSR)
                os.remove(filename)

def delDirFiles(gv, topDir, fileSpec):
    logger  = gv.LN.logger.setLogger(gv, pkgName=__name__)

    if (topDir == '/' or topDir == "\\" or topDir == ''):
        return

    for name in os.listdir(topDir):
        filename = os.path.join(topDir, name)
        if os.path.isfile(filename) and fnmatch.fnmatch(name, fileSpec):    # cerca il MATCH nel nome del file
            logger.debug( "removing File: %s" % (filename))
            # print( "removing File: %s" % (filename))
            os.chmod(filename, stat.S_IWUSR)
            os.remove(filename)

