import httplib2

gURL='http://jboss-swrepo.utenze.bankit.it/jboss/wsgiTest'
filename = 'curl_Loreto_1K.txt'



h = httplib2.Http()
# h.add_credentials(myname, mypasswd)
h.follow_all_redirects = True

headers = {'Content-Type': 'application/atom+xml'}

filename = 'curl_Loreto_1K.txt'
filename = 'p:\Python3\LnFunctions\LnNet\Samples\ping1.py'
f = open(filename, "rb")
chunk = f.read()
f.close()

body    = """<?xml version="1.0" ?>
    <entry xmlns="http://www.w3.org/2005/Atom">
      <title>Atom-Powered Robots Run Amok</title>
      <id>urn:uuid:1225c695-cfb8-4ebb-aaaa-80da344efa6a</id>
      <updated>2003-12-13T18:30:02Z</updated>
      <author><name>John Doe</name></author>
      <content>Some text.</content>
</entry>
"""

uri     = gURL
resp, content = h.request(uri, "POST", body=chunk, headers=headers)
print ()
print ()
print (resp)
print ()
print ()
print (content)
print ()
print ()
