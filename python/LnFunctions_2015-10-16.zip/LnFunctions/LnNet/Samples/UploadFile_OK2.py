#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#
# https://code.google.com/p/httplib2/wiki/Examples
#
# 28/02/2015 - Aggiunto il parametro di timeOUT

import httplib2
import pprint
# import socket
# import os

def uploadFile(URL, URI='', fileName=None, timeOUT=10, authTYPE=None, SSL=False, console=True):
    httplib2.debuglevel = 0

        # -----------------------------------
        # - preparazione della URL
        # -----------------------------------
    URI = URI.strip().replace('//', '/')
    if SSL:
        myURL = 'https://' + URL.strip() + URI
        conn = httplib2.Http(".cache", disable_ssl_certificate_validation=True)
    else:
        myURL = 'http://' + URL.strip() + URI
        conn = httplib2.Http(cache=None, timeout=timeOUT)                     # Non usare la cache ma usa timeOut

    # ----- BASILARE ------------------------------
    conn.follow_all_redirects = True
    # ----------------------------------------

    if authTYPE == 'BASIC': conn.add_credentials('ciaos', 'xyz') # Basic authentication

        # ---------------------------------------------------
        # - Lettura del file da inviare
        # ---------------------------------------------------
    try:
        f = open(fileName, "rb")
        chunk = f.read()
        f.close()

    except Exception as e:
        statusMSG = 'ERROR reading file:{0} - {1}'.format(fileName, e)
        print(statusMSG)
        sys.exit()


        # ---------------------------------------------------
        # - Messaggio a Console se richiesto
        # ---------------------------------------------------
    if console:
        if   'wsgi?::action=rename' in myURL:
            msg = "\n Renaming remote file...:"
        elif 'wsgi?::action=upload' in myURL:
            msg = "\n Uploading file...: {0}".format(fileName)
        else:
            msg = "\n Getting URL...:"

        print(msg)

    print("Executing HTTP: {0}".format(myURL))

        # ===========================
        # = Connecting
        # ===========================
    content, respFMTed, ERROR, statusCODE = '', '', True, 9999
    headers = {
        'Content-Type': 'application/atom+xml',
        'cache-control':'no-cache'
    }

    resp, content   = conn.request(myURL, method="POST", body=chunk, headers=headers)
    statusCODE      = resp.status
    pp              = pprint.PrettyPrinter(indent=4, width=10)
    respFMTed       = pp.pformat(resp).split('\n')
    print (pp)
    print (respFMTed)
    return resp, content


if __name__ == "__main__":
    import sys
    fileName = 'p:\Python3\LnFunctions\LnNet\Samples\ping1.py'
    error, page = uploadFile(URL='jboss-swrepo.utenze.bankit.it', URI='/jboss/wsgiTest', console=True, fileName=fileName)


    print ()
    print ()
    print (error)
    print ()
    print ()
    print (page)
    print ()
    print ()
    sys.exit()

