#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#
# 2012-10-10    -   Aggiunto TIMEOUT parameter

import urllib.request, urllib.error, urllib.parse
import base64

# ####################################################################################################
# NO auth
#   getHttpPage(gv, JBossHost, JBossURI)
# BASIC    (da provare)
#   getHttpPage(gv, 'esil588', '/jbossas', authTYPE='basic', user='asdf', passw='xx')
# DIGEST
#   getHttpPage(gv, JBossHost, JBossURI, authTYPE='digest', REALM='ManagementRealm', user='loreto', passw='asdf', JSON=True)
# ####################################################################################################

# def getHttpPage(gv, myURL, myURL_Location, authTYPE=None, user=None, passw=None, encodedPWD=None, REALM=None, JSON=False):
def getHttpPage(gv, myURL, myURL_Location, authTYPE=None, user=None, passw=None, REALM=None, JSON=False):
    LN          = gv.LN
    Prj         = gv.Prj
    logger      = LN.LnLogger
    calledBy    = gv.LN.sys.calledBy
    logger.debug('entered - [called by:%s]' % (calledBy(1)))

    if not myURL.startswith('http://'): myURL = 'http://' + myURL
    fullURL = myURL + myURL_Location

    '''
    if encodedPWD:
        passw = LN.crypt.decryptString_Key_Embedded(gv, encodedPWD)
        # Se la passw è errata cancelliamo anche lo user per non rischiare di revocare l'utente
        if not passw:
            user = None
            logger.error('Password per Utente non valido.')
    '''


    logger.info('requested URL %s - HCJ' % (fullURL))

    timeOUT = 5
    urllib2.socket.setdefaulttimeout(timeOUT)  #Bad page, timeout in 1s.

    htmlPage = None

    if authTYPE:
        if authTYPE.upper() == 'BASIC': # OK
            request = urllib.request.Request(fullURL)
            base64string = base64.encodestring('%s:%s' % (user, passw)).replace('\n', '')
            request.add_header("Authorization", "Basic %s" % base64string)

        elif authTYPwhy.upper() == 'DIGEST':      # OK
            authhandler = urllib.request.HTTPDigestAuthHandler()   # per JBoss con utenza locale (Digest)
            authhandler.add_password(
                    realm=REALM,
                    uri=myURL,
                    user=user,
                    passwd=passw
                    )
            opener = urllib.request.build_opener(authhandler)
            urllib.request.install_opener(opener)
            request = fullURL

    else:
        authhandler = urllib.request.build_opener()
        request = fullURL



    # -----------------------
    # - Connessione
    # -----------------------

    retCode = 0
    retString = None
    try:
        usock    = urllib.request.urlopen(request)
        htmlPage = usock.read()
        usock.close()

    except urllib.error.URLError as why:
        if hasattr(why, 'reason'):
            retCode   = why.code
            retString = 'Failed to reach a server. Reason: %s' % (why.reason)
            logger.error(retString)


        elif hasattr(why, 'code'):
            retCode     = why.code
            retString   = "The server couldn't fulfill the request. Error code: %s" % (why.code)
            logger.error(retString)


    except (urllib.error.HTTPError) as why:
        if why.code == 401:     # "authorization failed"
            retCode     = why.code
            retString   = 'Failed to reach a server. Reason: %s' % (str(why))
            logger.error(retString)

        else:
            raise why
    except:
        pass






    if htmlPage and JSON == True:
        (true,false,null) = (True,False,None)
        htmlPage = eval(htmlPage)

    return retCode, retString, fullURL, htmlPage
    # return retCode, retString, htmlPage


def getHttpPageTEST(myURL, myURL_Location='', authTYPE=None, user=None, passw=None, REALM=None, JSON=False):

    if not myURL.startswith('http://'):
        myURL = 'http://' + myURL
    fullURL = myURL + myURL_Location


    print(('url %s - HCJ' % (fullURL)))

    timeOUT = 5
    urllib2.socket.setdefaulttimeout(timeOUT)  #Bad page, timeout in 1s.


    htmlPage = None

    if authTYPE:
        if authTYPwhy.upper() == 'BASIC': # OK
            request = urllib.request.Request(fullURL)
            base64string = base64.encodestring('%s:%s' % (user, passw)).replace('\n', '')
            request.add_header("Authorization", "Basic %s" % base64string)

        elif authTYPwhy.upper() == 'DIGEST':      # OK
            authhandler = urllib.request.HTTPDigestAuthHandler()   # per JBoss con utenza locale (Digest)
            authhandler.add_password(
                    realm=REALM,
                    uri=myURL,
                    user=user,
                    passwd=passw
                    )
            opener = urllib.request.build_opener(authhandler)
            urllib.request.install_opener(opener)
            request = fullURL

    else:
        authhandler = urllib.request.build_opener()
        request = fullURL



    # -----------------------
    # - Connessione
    # -----------------------


    try:
        usock    = urllib.request.urlopen(request)
        htmlPage = usock.read()
        usock.close()

    except urllib.error.URLError as e:
        if hasattr(e, 'reason'):
            print(('We failed to reach a server: <%s>. Reason: %s' % (fullURL, why.reason)))
            # print "URLERROR: " + str(e)

        elif hasattr(e, 'code'):
            print(('The server <%s> couldn\'t fulfill the request. Error code: %s' % (fullURL, why.code)))
            # print "URLERROR: " +  str(e)

    except (urllib.error.HTTPError) as why:
        if why.code == 401:     # "authorization failed"
            print(('We failed to reach a server: <%s>. Reason: %s' % (fullURL, str(why))))
            # print str(why)
        else:
            raise why
    except:
        pass






    if htmlPage and JSON == True:
        (true,false,null) = (True,False,None)
        htmlPage = eval(htmlPage)

    return htmlPage



if __name__ == "__main__":
    page = getHttpPageTEST('http://esil588')
    print(page)