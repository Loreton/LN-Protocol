# http://www.blog.pythonlibrary.org/2012/08/02/python-101-an-intro-to-logging/
# otherMod.py

logger = None

# #####################################
# # Init LOG
# #####################################
logConfigFileName   = 'LnLogger.conf'
logDictName         = 'LnLoggerDict'
loggerName          = 'exampleApp'
import LnLogger
logger = LnLogger.init(logConfigFileName, logDictName, loggerName)

import Modulo_02 as otherMod; otherMod.initLog(loggerName) #; otherMod.loggerName = loggerName
# import Modulo_02 as otherMod; otherMod.loggerName = loggerName

def main():

    logger.info("Program started")
    result = otherMod.add(7, 8)
    logger.info("Done!")



if __name__ == "__main__":
    main()