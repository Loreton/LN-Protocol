# http://www.blog.pythonlibrary.org/2012/08/02/python-101-an-intro-to-logging/
# otherMod.py
import logging

# module_logger = logging.getLogger("exampleApp.altroModulo")
# print globals()
print __file__
print __name__

logger = None
loggerName = None

def initLog(logID):
    global loggerName
    loggerName  = logID + __name__
    logger      = logging.getLogger(loggerName)

#----------------------------------------------------------------------
def add(x, y):
    """"""
    logger = logging.getLogger("exampleApp.otherMod2.add")
    logger.info("added %s and %s to get %s" % (x, y, x+y))
    return x+y