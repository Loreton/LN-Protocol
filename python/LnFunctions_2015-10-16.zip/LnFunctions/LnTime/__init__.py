# outer __init__.py
# -*- coding: iso-8859-1 -*-


# from .TimeConvert        import timeConvert      as convert
# from .TimeGetNow         import timeGetNow       as now
# from .TimeFuncElapsed    import timeFuncElapsed  as funcElapsed
