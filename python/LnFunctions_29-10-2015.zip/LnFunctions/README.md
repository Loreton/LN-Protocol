LnFunctions3
============
