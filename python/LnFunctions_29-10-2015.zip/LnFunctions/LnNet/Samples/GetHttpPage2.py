#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#
# 2012-10-10    -   Aggiunto TIMEOUT parameter

import http.client
# http://stackoverflow.com/questions/6999565/python-https-get-with-basic-authentication

def getHttpPage(url):
    conn = http.client.HTTPConnection(url)
    conn.request('GET', '/index.html')
    resp = conn.getresponse()
    print(resp.status, resp.reason)
    body = resp.read()  # This will return entire content.
    conn.close()

    if resp.version == 10:
        print('HTTP/1.0 %s %s' % (resp.status, resp.reason))
    if resp.version == 11:
        print('HTTP/1.1 %s %s' % (resp.status, resp.reason))
    for header in resp.getheaders():
        print('%s: %s' % (header[0], header[1]))
    print ('\n', body)

if __name__ == "__main__":
    page = getHttpPage('2www.google.com')
    print(page)