import httplib2

gURL='http://jboss-swrepo.utenze.bankit.it/jboss/wsgiTest'
filename = 'curl_Loreto_1K.txt'


def uploadFile(URL, URI='', fileName=None, timeOUT=10, authTYPE=None, SSL=False, console=True):

    httplib2.debuglevel = 0

        # -----------------------------------
        # - preparazione della URL
        # -----------------------------------
    URI = URI.strip().replace('//', '/')
    if SSL:
        myURL = 'https://' + URL.strip() + URI
        conn = httplib2.Http(".cache", disable_ssl_certificate_validation=True)
    else:
        myURL = 'http://' + URL.strip() + URI
        conn = httplib2.Http(cache=None, timeout=timeOUT)                     # Non usare la cache ma usa timeOut


    # conn = httplib2.Http()
    # h.add_credentials(myname, mypasswd)
    conn.follow_all_redirects = True

    headers = {'Content-Type': 'application/atom+xml'}

    # filename = 'curl_Loreto_1K.txt'
    filename = 'p:\Python3\LnFunctions\LnNet\Samples\ping1.py'
    f = open(filename, "rb")
    chunk = f.read()
    f.close()

    body    = """<?xml version="1.0" ?>
        <entry xmlns="http://www.w3.org/2005/Atom">
          <title>Atom-Powered Robots Run Amok</title>
          <id>urn:uuid:1225c695-cfb8-4ebb-aaaa-80da344efa6a</id>
          <updated>2003-12-13T18:30:02Z</updated>
          <author><name>John Doe</name></author>
          <content>Some text.</content>
    </entry>
    """

    print("Executing HTTP: {0}".format(gURL))

    resp, content = conn.request(gURL, method="POST", body=chunk, headers=headers)
    return resp, content


if __name__ == "__main__":
    import sys
    fileName = 'p:\Python3\LnFunctions\LnNet\Samples\ping1.py'
    error, page = uploadFile(URL='jboss-swrepo.utenze.bankit.it', URI='/jboss/wsgiTest', console=True, fileName=fileName)
    # if not error:
    #     print(page)
    # print('..........................')


    print ()
    print ()
    print (error)
    print ()
    print ()
    print (page)
    print ()
    print ()
    sys.exit()
