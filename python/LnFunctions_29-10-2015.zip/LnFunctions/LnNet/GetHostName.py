#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#
# 2012-10-10    -   Aggiunto TIMEOUT parameter

import socket


# ####################################################################################################
# Due metodi:
#   import platform;    platform.node()
#   import socket;      socket.gethostname()
# ####################################################################################################

def getHostName(gv, short=False):
    logger = gv.LN.logger.setLogger(gv, pkgName=__name__)
    calledBy    = gv.LN.sys.calledBy

    logger.debug('entered - [called by:%s]' % (calledBy(1)))

    if socket.gethostname().find('.')>=0:
        hostName=socket.gethostname()
    else:
        hostName=socket.gethostbyaddr(socket.gethostname())[0]

    if short:
        hostName = hostName.split('.')[0]

    return hostName

