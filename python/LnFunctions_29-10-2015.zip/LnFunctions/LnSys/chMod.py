#!/usr/bin/python -O
# -*- coding: iso-8859-1 -*-
# -*- coding: latin-1 -*-
#                                               by Loreto Notarantonio 2013, February
# ######################################################################################
import sys
import subprocess
import os, platform
import shlex


# ###################################################################################################################
# ###################################################################################################################
def chMod(gv, fileName, attribValue):
    logger = gv.LN.logger.setLogger(gv, pkgName=__name__)
    calledBy = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(1)))

        # convertire il valore in OCTAL
    octalValue = int(str(attribValue), 8)

    currStatus = ''

    try:
        currStatus = oct(os.stat(fileName).st_mode)[4:]
        os.chmod(fileName, octalValue)

    except Exception as why:
        gv.LN.exit(gv, 4001, TABerr + 'ERROR - {}'.format(str(why)), console=True)

    return currStatus


# ###################################################################################################################
# ###################################################################################################################
def chMod_ALTERNATIVE(gv, fileName, attribValue):
    logger = gv.LN.logger.setLogger(gv, pkgName=__name__)

    calledBy = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(1)))

    TAByel      = gv.LN.cYELLOW + ' '*8
    TABerr      = gv.LN.cERROR + ' '*8

    CMD = "chmod {ATTR} '{FILE}'".format(ATTR=attribValue, FILE=fileName)
    logger.info('modifying attribute to file:'.format(fileName))

    logger.info('executing command: {}'.format(CMD))
    print (TAByel + CMD, end="")
    rCode =  subprocess.call(shlex.split(CMD))
    print (" - [RC:{}]".format(rCode))
    if rCode:
        gv.LN.exit(gv, 4001, TABerr + 'ERROR - cannot proceed', console=True)