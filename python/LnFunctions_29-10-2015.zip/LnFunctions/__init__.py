#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
import sys, os; sys.dont_write_bytecode = True

import platform
OpSys = platform.system()
# import types
# def isDictionary(obj):
#     if isinstance(obj, dict):
#         return True
#     elif isinstance(obj, gv.Prj.LnClass):
#         return True
#     else:
#         return False

class LnClass(): pass
    # Inserimento statico di una property
    #     gv.myItem = 'pippo'
    #
    # Inserimento dinamico(variabile) di una property
    #     ItemName = scriptName+'.ini'
    #     valore   = 'pippo'
    #     setattr(gv, ItemName, valore)
    #     gv.myItem = getattr(gv, ItemName)

# gVars = LnClass()

# -----------------------------------------------------------------------------------------------------------------------
# Type 1
#     - punto a Ln.logger.LnLogger.function()   se nel prossimo __init__ non metto nulla
#     - punto a Ln.logger.function()            se nel prossimo __init__ inserisco <from    LnLogger        import *> ciao
# -----------------------------------------------------------------------------------------------------------------------
from . import LnNet                    as net
from . import LnList                    as list
from . import LnLogger                 as logger
from . import LnDictionary             as dict
from . import LnSys                    as sys
from . import LnFile                   as file
from . import LnString                 as string
from . import LnFormat                 as fmt
from . import LnTime                   as time
from . import LnCrypt                   as crypt


if platform.system() == 'Windows':
    from . import LnWindowsProcess             as proc
else:
    from . import LnUnixProcess                as proc



from . LnSys.Exit                      import exit                     # richiamato LN.exit(gv, rcode, text)
from . LnSys.Enumerate                 import enumerateClass3 as enum3
from . LnSys.Enumerate                 import enumerateClass2 as enum2
from . LnSys.Enumerate                 import enumerateClass2A as enum2A
from . LnSys.Varie                     import isAscii
from . LnSys.Varie                     import lnPrint
# from . LnSys.chOwn                     import chOwn
# from . LnSys.chMod                     import chMod
# from . LnSys.chOwn                     import chGrp

if OpSys == 'Windows':
    # from . import LnExcel                  as excel
    pass

# =========================================================================
# Fore:  BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE, RESET.
# Back:  BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE, RESET.
# Style: DIM, NORMAL, BRIGHT, RESET_ALL
# =========================================================================
from . import colorama as color

colorama.init(autoreset=True)
FG          = colorama.Fore
BG          = colorama.Back
HI          = colorama.Style
cCRITICAL   = FG.BLUE
cERROR      = FG.RED
cWARNING    = FG.MAGENTA
cINFO       = FG.GREEN

cBLACK      = FG.BLACK
cRED        = FG.RED
cGREEN      = colorama.Fore.GREEN
cYELLOW     = FG.YELLOW
cBLUE       = FG.BLUE
cMAGENTA    = FG.MAGENTA
cCYAN       = FG.CYAN
cWHITE      = FG.WHITE

cRESET      = HI.RESET_ALL


cBW       = FG.BLACK + BG.WHITE
cBWH      = FG.BLACK + BG.WHITE + HI.BRIGHT





# -----------------------------------------------------------------------------------------------------------------------
#  Type 2 - al porto del type-1 se devo mascherare una subDirectory
# -----------------------------------------------------------------------------------------------------------------------
# import LnLogger.subDir                as logger        # punto a Ln.logger.function()

# -----------------------------------------------------------------------------------------------------------------------
#  Type 3 - Punto direttamente alla funzione LN.function()
# -----------------------------------------------------------------------------------------------------------------------
# from LnDictionary.printDictionaryTree   import printDictionaryTree  as printTree
# from LnDictionary.printDictionaryTree   import getDictionaryTreeUnderTest  as printTreeUT
# from LnFile.LN_ReadIniFile              import readIniConfigFile    as configFile


