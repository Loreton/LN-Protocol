#!/usr/bin/python3
# -*- coding: iso-8859-1 -*-
# dictTYPES = [dict, configparser.ConfigParser, configparser.SectionProxy, gv.Prj.LnClass, gv.gv.LN.LnClass, collections.OrderedDict]
#
# Scope:  Funzioni per operare sul python dictionary
#                                               by Loreto Notarantonio 2013, February
# ######################################################################################

import sys
import types
import collections, configparser
import argparse


# #########################################################################################
# - printDictionaryTree() ordered
# - CALL: printDictionaryTree(CfgDict, MaxDeepLevel=3, values=True, lTAB=' '*12)
# - PARAMS:
# -     level:          serve per tenere traccia delle iterazioni ed anche per l'indentazione
# -     MaxDeepLevel:   Indica il numero MAX di profondità (iterazioni) da raggiungere
# -     values:         Indica se ritornare anche il valore delle keys
# -     lTAB:           Prefix a sinistra della riga
# -     retCols:         'LTV'
# -                        L  se vogliamo LevelCol
# -                        T  se vogliamo Type
# -                        V  se vogliamo Value
# -
# #########################################################################################
import re
allDictTYPES = []
myDictTYPES  = []

def  printDictionaryTree(gv, dictID, header=None, MaxDeepLevel=999, level=0, retCols='LTV', lTAB='', console=True, listInLine=5, exit=False):
    global allDictTYPES, myDictTYPES

    gVars       = gv
    LN          = gv.LN
    logger      = gv.LN.logger.setLogger(gv, pkgName=__name__)
    calledBy    = gv.LN.sys.calledBy
    myDictTYPES = gv.myDictTYPES
    logger.info('entered - [called by:%s]' % (calledBy(1)))

    pyDictTYPES = [ dict,
                    configparser.ConfigParser,
                    configparser.SectionProxy,
                    collections.OrderedDict,
                    ]

    allDictTYPES.extend(pyDictTYPES)
    allDictTYPES.extend(myDictTYPES)

    lista = getDictionaryTree(dictID, MaxDeepLevel=MaxDeepLevel, level=level, retCols=retCols, listInLine=listInLine)

    if console:
        # COLOR = gv.LN.Common.cBWH
        # COLOR = gv.LN.Common.cWHITE + gv.LN.HI.BRIGHT
        # COLOR = gv.LN.Common.cMAGENTA
        COLOR = ''
        COLOR = gv.LN.cCYAN

        if header:
            print()
            print(lTAB + COLOR + "*"*60)
            print(lTAB + COLOR + "*     %s" % (header))
            print(lTAB + COLOR + "*"*60)
        for line in lista:
            if not isAscii(line): line = str.encode(line, 'utf-8')
            print(COLOR + "{}{}".format(lTAB, line))

    if exit:
        print("Exiting on user request.")
        sys.exit(0)

    return lista


def isAscii(s):
    try:
        return all(ord(c) < 128 for c in s)
    except TypeError:
        return False


# #########################################################################################
# - getDictionaryTree()
# -
# - PARAMS:
# -     level:          serve per tenere traccia delle iterazioni ed abche per l'indentazione
# -     MaxDeepLevel:   Indica il numero MAX di profondità (iterazioni) da raggiungere
# -     values:         Indica se ritornare anche il valore delle keys
# -
# - RETURN: LIST of the keys with level indication:
# -            LVL TYPE       KeyName
# -            [0] dict       JbossColl
# -            [1] list           PATHS
# -            [1] str            Source System
# -            [1] str            Target System
# -            [0] int        LOG_CONSOLE
# -            [0] int        LOG_FILE
# -            [0] dict       Portit_DiscoL
# -            [1] dict           Flusso_DiscoL_With_BACKUP
# -            [2] list               PATHS
# -            [2] str                Source System
# -            [2] str                Target System
# -            [0] str        Type_of_Command
# -            [0] str        esil601
# -     Es.:
# -       [0] str          user.timezone                    : GMT+1
# -       [0] bool         javax.xml.jaxp-provider          : True
# -       [0] int          BdI.txn-status-manager.port      : 4713
# -
# - E' possibile utilizzarlo anche per leggere un modulo caricato con il comando:
# -         configFileID = loadConfigModule(Fname)
# -         CfgDict = vars(configFileID)        # con il comando vars trasformo il modulo in dictionary
# -
# -         lista = getDictionaryTree_Prev(vars(configFileID))
# -         lista = getDictionaryTree_Prev(CfgDict)
# #########################################################################################
def getDictionaryTree(dictID, MaxDeepLevel=999, level=0, retCols='LTV', listInLine=5):
    lista = []

    if MaxDeepLevel < 0: return lista

    thisDictType = type(dictID)
    values = (True if 'V' in retCols else False)
    if not thisDictType in allDictTYPES:
        return lista

    if thisDictType in myDictTYPES:
        dictID = vars(dictID) # custom class


        # ------ Stiamo trattando un dictionary
    for key, val in sorted(dictID.items()):
        if type(val) in myDictTYPES:
            # valueType = type(val)
            # print('---------- valueType ------------------', valueType)
            val = vars(val)
            valueTypeStr = 'LnClass'
        else:
            valueTypeStr = str(type(val)).split("'")[1]

        valueType = type(val)

        if key.startswith('__') and key.endswith('__'): continue    # elimina tutti i built-in (presente in un modulo)

        if valueType == types.ModuleType:
            continue                                # elimina eventuali import (presente in un modulo)


        newLine = "%s %s" % (' '*level*4, key)        # base della Linea
        if 'T' in retCols: newLine = "%-12s    %s" % (valueTypeStr, newLine)        # aggiungiamo il TYPE
        if 'L' in retCols: newLine = "[%2d] %s"   % (level, newLine)        # aggiungiamo il LEVEL

        if valueType in allDictTYPES:
        # if valueType in (pyDictTYPES, myDictTYPES):
            continue

        if values:
            if valueType in [bytes, str]:
                if val.strip() == '':
                    val = '"' + val + '"'
                val = val.replace('\n', ' ')        # vale per le righe multiline (tipo nel file.ini)
                newLine = "%-50s: %s" % (newLine.rstrip(), val.strip())
                lista.append(newLine)

            elif isinstance(val, enumerate):
                lista.append("%-50s: [" % (newLine.rstrip()))          # Apertura LIST
                for index, name in val:
                    newLine = prepareListValueLine(name, retCols, level)
                    lista.append(newLine)

                lista.append('%-50s: ]' %(' ') )                # Chiusura LIST

            elif valueTypeStr.endswith('.enumerateClass'):
                ENUM_SORTED_BY_VALUE = True
                lista.append("%-50s: [" % (newLine.rstrip()))   # Apertura LIST
                thisDICT = vars(val)                            # Devo trasformarlo in DICT per analizzarlo.
                if ENUM_SORTED_BY_VALUE:                        # print sorted by value (comodo se il valore è numerico)
                    for w in sorted(thisDICT, key=thisDICT.get, reverse=False):
                        lista.append('%-54s: %20s.%02d' % (" ", w, thisDICT[w]))
                else:                                           # print normale
                    for key, value in sorted(thisDICT.items()):
                        lista.append('%-54s: %20s.%02d' % (" ", key, value))
                lista.append('%-50s: ]' %(' ') )                # Chiusura LIST


            elif valueType == list:
                if len(val) == 0:                                               # Enpty LIST
                    newLine = "%-50s: []" % (newLine.rstrip())                  # Enpty LIST
                    lista.append(newLine)

                elif len(val) <= listInLine:                                      # scriviamo la lista INLINE e non su righe diverse.
                    newLine = "%-50s: [%-10s" % (newLine.rstrip(), val[0])      # Scrivi anche il primo valore (per allinearlo)
                    for item in val[1:]:                                        # Scrivi gli altri items
                        newLine += " %5s" % (item)
                    newLine += " ]"
                    lista.append(newLine)
                else:
                    lista.append("%-50s: [" % (newLine.rstrip()) )             # Apertura LIST
                    counter = 0
                    for line in val:
                        if type(line) in allDictTYPES:            # Dictionary interno ad una LIST
                        # if type(line) in (pyDictTYPES, myDictTYPES):            # Dictionary interno ad una LIST
                            counter += 1
                            level += 1
                            lista.append('')
                            lista.append('[%2d] dict-%02d' % (level, counter))
                            newLista = getDictionaryTree(line, MaxDeepLevel=MaxDeepLevel-1, level=level+1, retCols=retCols)
                            lista.extend(newLista)
                            level -= 1
                            continue

                        newLine = prepareListValueLine(line, retCols, level+1)
                        lista.append(newLine)

                    # lista.append('%-50s: ]' %(' ') )            # Cjhiusura LIST
                    newLine = prepareListValueLine(': ]', retCols, level+1) # Chiusura LIST
                    lista.append(newLine)

            elif valueType == bool or\
                 valueType == type(None) or\
                 valueType == int or\
                 valueType == int or\
                 valueType == float or\
                 valueTypeStr == "datetime.date":
                newLine = "%-50s: %s" % (newLine.rstrip(), val)
                lista.append(newLine)

            else:
                lista.append(newLine)

        else:
            lista.append(newLine)

    lista.append('')    # separator


        # Analisi di tutte le chiavi che sono a livello del dictionary.
    for key, val in sorted(dictID.items()):
        valueTypeStr = str(type(val)).split("'")[1]
        valueType    = type(val)
        if   valueType in myDictTYPES: valueTypeStr = 'LnClass'
        elif valueTypeStr == 'configparser.ConfigParser': valueTypeStr = 'ConfigParser'
        elif valueTypeStr == 'configparser.SectionProxy': valueTypeStr = 'INISection'
        elif valueTypeStr == 'collections.OrderedDict':   valueTypeStr = 'ordDict'


        if key.startswith('__') and key.endswith('__'): continue    # elimina tutti i built-in (presente in un modulo)

        if valueType == types.ModuleType: continue                                # elimina eventuali import (presente in un modulo)

            # ==============================================
            # - Ahghiunto il 16-06-2014 per allineare
            # - ConfigParser al corretto livello.
            # ==============================================
        if valueTypeStr == 'ConfigParser':
            newLine = "%s %s" % (' '*(level-1)*4, key)        # base della Linea
        else:
            newLine = "%s %s" % (' '*level*4, key)        # base della Linea

        if 'T' in retCols: newLine = "%-12s    %s" % (valueTypeStr, newLine)        # aggiungiamo il TYPE
        if 'L' in retCols: newLine = "[%2d] %s"   % (level, newLine)                # aggiungiamo il LEVEL

        if valueType in allDictTYPES:
        # if valueType in (pyDictTYPES, myDictTYPES):
            lista.append(newLine)
            newLista = getDictionaryTree(val, MaxDeepLevel=MaxDeepLevel-1, level=level+1, retCols=retCols)
            lista.extend(newLista)
            lista.append('')

    return lista



###################################################################
#
###################################################################
def prepareListValueLine(line, retCols, level):
    newLine = ''
    offSet = ' '*5

    valueTypeStr = str(type(line)).split("'")[1]

    if isinstance(line, str):
        if line == ': ]':
            valueTypeStr = 'endOfLIST.........'
            offSet = ''                             # per la formattazione
        elif line.endswith(': ['):
            valueTypeStr = 'startOfLIST'

    if 'T' in retCols:
        str(type(line)).split("'")[1]
        newLine = "%-12s %s" % (valueTypeStr, newLine)        # aggiungiamo il TYPE
    if 'L' in retCols:
        newLine = "[%2d] %s"   % (level, newLine)        # aggiungiamo il LEVEL

    newLine = "%-49s%s %s" % (newLine, offSet, line)
    return newLine
