#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# Scope: Lettura e scrittura di un file di configurazione nel formato INI
# ######################################################################################

import configparser, sys
import collections

class FileStripper(object):
    def __init__(self,f):
        self.fileobj = open(f)
        self.data = ( x.strip() for x in self.fileobj )
    def readline(self):
        return next(self.data)
    def close(self):
        self.fileobj.close()

# parser = SafeConfigParser()
# f = FileStripper(yourconfigfile)
# parser.readfp(f)
# f.close()



# ######################################################
# # https://docs.python.org/3/library/configparser.html
#        '''
#        mySection = """
#                    [EXTRA_SECTION
#        fullConfig = mySection.format(INIFILE=text)
#        '''
# ######################################################
# def readIniFile(gVars, inputData, isFile=True, validate=True, extraSections=[], writeOnFile=False, exitOnError=False):
def readIniFile(gVars, inputData, isFile=True, extraSections=[], RAW=False, rawName=None, writeOnFile=False, exitOnError=False):
    global logger, gv
    gv = gVars
    logger = gv.LN.logger.setLogger(gv, pkgName=__name__)
    calledBy    = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(1)))



        # Setting del parser
    configMain = getConfigPtr(gv, inputData, isFile)
        # Salviamo la struttura nelle gv
    if rawName:setattr(gv.INI_RAW, rawName, configMain)

    # per poter leggere i dati senza la risoluzione delle variabili


    TEST_RAW = True
    TEST_RAW = False
    if TEST_RAW:
        MAX_KEY_LEN = gv.LN.dict.getMaxKeyLen_Raw(configMain)
        indent = ' '*4
        for sectionName in configMain.sections():
            print ('\n[{}]'.format(sectionName))
            for key, val in configMain.items(sectionName, raw=True):
                print('{0}{1:{2}} = {3}'.format(indent, key, MAX_KEY_LEN, val))

        sys.exit()





        # ------------------------------------------------------------------
        # - per tutte le sezioni che sono extra facciamo il merge.
        # - Se Key-Val esistono esse sono rimpiazzate
        # ------------------------------------------------------------------
    logger.info('adding extra sections: {}'.format(extraSections))
    for extraSect in extraSections:
        logger.info('adding extraSection: {}'.format(extraSect))

        configExtra = getConfigPtr(gv, extraSect, isFile=False)
        for sectionName in configExtra.sections():
            if not configMain.has_section(sectionName):
                logger.debug('adding Section: {}'.format(sectionName))
                configMain.add_section(sectionName)

            for key, val in configExtra.items(sectionName, raw=RAW):
                logger.debug('adding key: {} = {}'.format(key, val))
                configMain.set(sectionName, key, val)

        # Parsing del file
    if type(configMain) in [configparser.ConfigParser]:
        configDict = iniConfigAsDict(configMain, inputData=extraSections, raw=RAW)
    else:
        configDict = configMain
    # sys.exit()

    if writeOnFile:
        gv.LN.dict.writeIniFile(gv, writeOnFile, configMain, RAW=RAW, INDENT=True)
    logger.info('exiting - [called by:%s]' % (calledBy))

    return configMain, configDict





import codecs
from io import StringIO as StringIO
# ######################################################
# #
# ######################################################
def getConfigPtr(gv, data, isFile):
    logger = gv.LN.logger.setLogger(gv, pkgName=__name__)
    config = configparser.ConfigParser( allow_no_value=False,
                                        delimiters=('=', ':'),
                                        comment_prefixes=('#',';'),
                                        inline_comment_prefixes=(';',),
                                        strict=True,
                                        empty_lines_in_values=True,
                                        default_section='DEFAULT',
                                        interpolation=configparser.ExtendedInterpolation()
                                    )
    config.optionxform = str        # mantiene il case nei nomi delle section e delle Keys (Assicurarsi che i riferimenti a vars interne siano case-sensitive)
    try:
        if isFile:
            fName = data
            logger.info('isFile = True: FileName:{}'.format(fName))

            REMOVE_TABS = False
            if REMOVE_TABS:
                    # Questa soluzione e' in test. Leggiamo in binario e replace del '\t'
                f = open(fName,"r"); text = f.read(); f.close()
                data = text.replace('\t', ' '*4)
                config.read_string(data)

            else:
                    # Questa soluzione funziona.
                data = codecs.open(fName, "r", "utf8")
                config.readfp(data)


        elif isinstance(data, dict):
            logger.info("it's dictionary")
            config.read_dict(data)

        elif isinstance(data, str):
            logger.info("it's string data")
            config.read_string(data)

        else:
            gv.LN.exit(gv, 5001, "dataType={} - ERROR..... during readIniFile. Should NOT occur!".format(type(data)))

    except (Exception) as why:
        gv.LN.exit(gv, 5001, str(why), console=True)


    return config


############################################################
#
############################################################
def iniConfigAsDict(INIConfig, sectionName=None, inputData=None, raw=False):
    """
    Converts a ConfigParser object into a dictionary.

    The resulting dictionary has sections as keys which point to a dict of the
    sections options as key => value pairs.
    """

    # the_dict = {}
    the_dict = collections.OrderedDict({})

    try:
        for section in INIConfig.sections():
            # the_dict[section] = {}
            the_dict[section] = collections.OrderedDict({})
            for key, val in INIConfig.items(section, raw=raw):
                the_dict[section][key] = val

    except (configparser.InterpolationMissingOptionError) as why:
        print(gv.LN.cRED)
        print("\n"*2)
        print("="*60)
        # ---- Da ERRORE con list ----
        if isinstance(inputData, list):
            pass
        else:
            print("ERRORE nella validazione del file:\n{}".format(gv.LN.cYELLOW + inputData))
        print("-"*60)
        print(gv.LN.cRED + str(why))
        print("="*60)
        gv.LN.exit(gv, 1501, "ERRORE nella validazione del file:\n{}".format(inputData))


    if sectionName:
        return the_dict[sectionName]
    else:
        return the_dict

############################################################
#
############################################################
def getMaxKeyLen_Raw(config):
    MAX_KEY_LEN = 0
    for sectionName in config.sections():
        for key, val in config.items(sectionName, raw=True):
            keyLen = len(key)
            if keyLen > MAX_KEY_LEN: MAX_KEY_LEN = keyLen

    return MAX_KEY_LEN




if __name__ == "__main__":
    import os

    thisModuleDIR   = os.path.dirname(os.path.realpath(__file__))

    iniFileName02 = os.path.join(thisModuleDIR, 'Samples/template01.ini')
    iniFileName01 = os.path.join(thisModuleDIR, 'Samples/template02.ini')

    configID02 = readIniFile(iniFileName02)


        # - Preparazione della DynamicVars Section
    text =  """
                [RUN_TIME_VARS1]
                    JBossHome           = {JBOSS_HOME}
                    JBossAdminConfDir   = {JBOSS_ADMIN_CONF_DIR}
                    shortHostName1       = {HOSTNAME}
                    scriptName       = {HOSTNAME}
            """
    DynamicVarsSection = text.format(JBOSS_HOME="JBossLoreto",JBOSS_ADMIN_CONF_DIR="MyDIR", HOSTNAME='ESL424')

    textDict =  {'RUN_TIME_VARS': {
                        'JBossHome'           : "JBossLoreto",
                        'JBossAdminConfDir'   : "MyDIR",
                        'shortHostName'       : 'ESL424',
                        'scriptName'       : "E' il mio scriptName",
                    },
                }




        # extraSections può contenere le Setion in formato DICT oppure STR
    configID = readIniFile(iniFileName, extraSections=[textDict, DynamicVarsSection])
    # printConfig(configID)




