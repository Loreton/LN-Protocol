#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# Scope: Lettura e scrittura di un file di configurazione nel formato INI
# ######################################################################################




############################################################
#
############################################################
def getMaxKeyLen_Raw(config):
    MAX_KEY_LEN = 0
    for sectionName in config.sections():
        for key, val in config.items(sectionName, raw=True):
            keyLen = len(key)
            if keyLen > MAX_KEY_LEN: MAX_KEY_LEN = keyLen

    return MAX_KEY_LEN

############################################################
#
############################################################
def getMaxKeyLen(config):
        # ------ TEST per verificare che non ci siano variabili irrisolte nel configParser - Devo trovare un'altra soluzione
    MAX_KEY_LEN = 0
    # try:
    for section in config.sections():
        sectID  = config[section]
        for key, val in sectID.items():
            keyLen = len(key)
            if keyLen > MAX_KEY_LEN: MAX_KEY_LEN = keyLen

    # except (configparser.InterpolationMissingOptionError) as why:
    #     print(gv.LN.cRED)
    #     print("\n"*2)
    #     print("="*60)
    #     print("ERRORE nella validazione del file:\n{}".format(gv.LN.cYELLOW + config))
    #     print("-"*60)
    #     print(gv.LN.cRED + str(why))
    #     print("="*60)
    #     gv.LN.exit(gv, 1501, "ERRORE nella validazione del file:\n{}".format(config))

    return MAX_KEY_LEN
