#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

import os

def rotateFilesSeqNo(gv, basicFileName, nFiles=20):
    logger      = gv.LN.logger.setLogger(gv, pkgName=__name__)

    if os.path.isfile(basicFileName):
        # print (basicFileName)
        for index in reversed(range(1, nFiles+1)):  # range 20 to 01
            fnameUp = basicFileName + '.{:>02}'.format(index)  # '0' left justified
            fnameDn = basicFileName + '.{:>02}'.format(index-1)  # '0' left justified
            if os.path.isfile(fnameDn):
                logger.info('moving {} to {}'.format(fnameDn, fnameUp))
                if os.path.isfile(fnameUp): os.remove(fnameUp)
                os.rename(fnameDn, fnameUp)

        os.rename(basicFileName, basicFileName + '.01')

    # create it
    logger.info('creating file: {}'.format(basicFileName))
    gv.LN.proc.runCommand(gv, 'touch', argsList=[basicFileName])

    return
