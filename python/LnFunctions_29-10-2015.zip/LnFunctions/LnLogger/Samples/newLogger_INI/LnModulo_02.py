# http://www.blog.pythonlibrary.org/2012/08/02/python-101-an-intro-to-logging/
# otherMod2.py
import os, sys
import logging

baseLoggerName = 'Appl01'
import LnModulo_03 as Modulo3

#----------------------------------------------------------------------
def add1(x, y):
    """"""
    # loggerName = os.getenv('LN_loggerName') + '.' + __name__
    # logger = logging.getLogger(loggerName + ".add1")
    loggerName = "%s.%s.%s" % (baseLoggerName, __name__,  'add1')
    logger = logging.getLogger(loggerName)
    logger.info("added %s and %s to get %s" % (x, y, x+y))
    return x+y

def add2(x, y):
    """"""
    # loggerName = os.getenv('LN_loggerName') + '.' + __name__
    # logger = logging.getLogger(loggerName + ".add2")
    loggerName = "%s.%s.%s" % (baseLoggerName, __name__,  'add2')
    logger = logging.getLogger(loggerName)

    logger.info("added %s and %s to get %s" % (x, y, x+y))
    return x+y

def add3(x, y):
    """"""
    # loggerName = os.getenv('LN_loggerName') + '.' +  __name__
    funcName = sys._getframe().f_code.co_name
    loggerName = "%s.%s.%s" % (baseLoggerName, __name__,  funcName)
    logger = logging.getLogger(loggerName)

    logger.debug("added %s and %s to get %s" % (x, y, x+y))
    return x+y


def prova():
    result = Modulo3.add1(7, 8)
    result = Modulo3.add2(7, 8)
    result = Modulo3.add3(7, 8)