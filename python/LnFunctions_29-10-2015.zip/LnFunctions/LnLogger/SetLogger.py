#!/usr/bin/python -O
# -*- coding: iso-8859-15 -*-
# -O Optimize e non scrive il __debug__
#
# Version 0.01 08/04/2010:  Starting
# ####################################################################################################################
import sys, os
import logging


savedModules = []
    # ========================================================
    # - SetUp del log
    # ========================================================
def setLogger(gv, logFile=None, pkgName=None, fDEBUG=False):
    global savedModules
    callerFunc1 = sys._getframe( 1 ).f_code.co_name
    callerFunc2 = ''
    callerFunc3 = ''
    try:
        callerFunc2 = sys._getframe( 2 ).f_code.co_name
        callerFunc3 = sys._getframe( 3 ).f_code.co_name
    except:
        pass



        # ------------------------------------------------
        # - del packageHier cerchiamo di prendere
        # - solo gli ultimi due qualificatori.
        # ------------------------------------------------
    packageHier = pkgName.split('.')
    loggerName  = ('.'.join(packageHier[-2:]))

    if logFile:
        try:
            logging.config.fileConfig(logFile, disable_existing_loggers=False)
        except Exception as why:
            gv.LN.sys.exit(gv, 2001, "{} - ERROR in file: {}".format(str(why), logFile), console=True)

    logger = logging.getLogger(loggerName)

    savedLevel = logger.getEffectiveLevel()
    if logFile:
        logger.setLevel(logging.INFO)
        for i in range(1,10):   logger.info(' ')
        for i in range(1,5):    logger.info('-'*40 + 'Start LOGging' + '-'*20)
        logger.setLevel(savedLevel)

    return logger






    fDEBUG = True
    fDEBUG = False
    TAB = ' '*5 + gv.LN.cWARNING
    if fDEBUG:
        # print (TAB + 'SONO QUI fDEBUG ......................................', pkgName)
        # print(TAB + 'pkgName ..........' +  pkgName)
        # print(TAB + 'callerFunc1 ..........' +  callerFunc1)
        # print(TAB + 'callerFunc2 ..........' +  callerFunc2)
        # print(TAB + 'callerFunc3 ..........' +  callerFunc3)
        pass

        # Se il DEBUG è stato indicato per il package corrente allora attiviamolo
    if gv.DEBUG:
        debugModules    = gv.DEBUG.split(',')
        pkgName         = ('.' + pkgName).replace('.Ln', '.')  # eliminiamo il prefisso Ln dal nome delle funzioni
        pkgName         += '.ALL'               # aggiungiamo la ALL function
        pkgName         += '.' + callerFunc1    # aggiungiamo caller Funcion
        pkgName         += '.' + callerFunc2    # aggiungiamo caller Funcion
        pkgName         += '.' + callerFunc3    # aggiungiamo caller Funcion

        packageList     = pkgName[1:].split('.')                    # Salta il '.' inserito precedentemente e fai split
        packageListUPP  = pkgName[1:].upper().split('.')                    # Salta il '.' inserito precedentemente e fai split



        msg = 'debugModules: [{}] in packages:[{}]'.format(' '.join(debugModules), pkgName)
        if fDEBUG: print(TAB + msg)
        logger.warning(msg)


        EXACT_MODULE_NAME = False
        for index, moduleName in enumerate(debugModules):
            if EXACT_MODULE_NAME:
                        # cerchiamo in UPPERCASE ma stampiamo il case corretto
                    if moduleName.upper() in packageListUPP:
                        logger.setLevel(logging.DEBUG)
                        msg = "DEBUG set for function: [{}]".format(moduleName)
                        if fDEBUG: print(TAB + msg)
                        logger.warning(msg)
                    else:
                        msg="SKIPped set for function: [{}]".format(moduleName)
                        if fDEBUG: print(TAB + msg)
                        logger.warning(msg)


            else:
                if moduleName.upper() in pkgName.upper():
                    logger.setLevel(logging.DEBUG)
                    msg = "DEBUG set for function: [{}]".format(moduleName)
                    if fDEBUG: print(TAB + msg)
                    logger.warning(msg)

                else:
                    msg = "SKIPped set for function: [{}]".format(moduleName)
                    if fDEBUG: print(TAB + msg)
                    logger.warning(msg)



    return logger
