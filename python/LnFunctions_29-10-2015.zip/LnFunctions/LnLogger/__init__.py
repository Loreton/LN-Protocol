# outer __init__.py
# -*- coding: iso-8859-1 -*-


# from    LnLogger        import init as initLog
from    . SetLogger        import setLogger
# from    . SetLogger        import initLogger
